chipkit-core
============

The core of the pic32 Arduino compatible libraries. The goal is to be Arduino 1.5.x compatible.
